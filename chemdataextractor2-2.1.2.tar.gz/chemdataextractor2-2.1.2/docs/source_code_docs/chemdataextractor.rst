=========================
chemdataextractor
=========================

.. automodule:: chemdataextractor
    :members:
    :undoc-members:

.config
------------------------------------------------

.. automodule:: chemdataextractor.config
    :members:
    :undoc-members:

.data
------------------------------------------------

.. automodule:: chemdataextractor.data
    :members:
    :undoc-members:

.errors
------------------------------------------------

.. automodule:: chemdataextractor.errors
    :members:
    :undoc-members:

.utils
------------------------------------------------

.. automodule:: chemdataextractor.utils
    :members:
    :undoc-members:


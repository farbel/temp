======================
.eval
======================


.. automodule:: chemdataextractor.eval
    :members:
    :undoc-members:

.eval.evaluation
------------------------------------------------

.. automodule:: chemdataextractor.eval.evaluation
    :members:
    :undoc-members:


#!/bin/bash

set -x

${PYTHON} build.py


Reference Manual
================

.. toctree::

   types.rst
   jit-compilation.rst
   aot-compilation.rst
   utils.rst
   envvars.rst
   pysupported.rst
   numpysupported.rst
   pysemantics.rst
   fpsemantics.rst
   deprecation.rst

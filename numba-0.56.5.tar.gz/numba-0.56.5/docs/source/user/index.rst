
User Manual
===========

.. toctree::

   5minguide.rst
   overview.rst
   installing.rst
   jit.rst
   generated-jit.rst
   vectorize.rst
   jitclass.rst
   cfunc.rst
   pycc.rst
   parallel.rst
   stencil.rst
   withobjmode.rst
   jit-module.rst
   performance-tips.rst
   threading-layer.rst
   cli.rst
   troubleshoot.rst
   faq.rst
   examples.rst
   talks.rst
